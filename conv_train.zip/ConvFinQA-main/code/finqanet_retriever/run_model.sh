#!/bin/bash

export CUDA_VISIBLE_DEVICES=2,3,4,5

python Main.py
