#!/bin/bash

export CUDA_VISIBLE_DEVICES=0,1,2,7

python Main.py
